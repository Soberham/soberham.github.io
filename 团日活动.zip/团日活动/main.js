// Global variables
let currentQuestionIndex = 0;
let quizScore = 0;
let selectedAnswers = [];
let particleSystem;

// Quiz data
const quizData = [
    {
        question: "抗日战争全面爆发的标志是什么？",
        options: ["九一八事变", "卢沟桥事变", "八一三事变", "南京大屠杀"],
        correct: 1,
        explanation: "1937年7月7日的卢沟桥事变是抗日战争全面爆发的标志。"
    },
    {
        question: "以下哪位是抗日英雄？",
        options: ["杨靖宇", "张学良", "李鸿章", "袁世凯"],
        correct: 0,
        explanation: "杨靖宇是东北抗日联军的主要领导人之一，是著名的抗日英雄。"
    },
    {
        question: "抗日战争持续了多少年？",
        options: ["8年", "10年", "12年", "14年"],
        correct: 3,
        explanation: "从1931年九一八事变到1945年日本投降，共持续了14年。"
    },
    {
        question: "《义勇军进行曲》创作于哪一年？",
        options: ["1931年", "1934年", "1935年", "1937年"],
        correct: 2,
        explanation: "《义勇军进行曲》创作于1935年，由田汉作词，聂耳作曲。"
    },
    {
        question: "日本正式宣布无条件投降的日期是？",
        options: ["1945年8月15日", "1945年9月2日", "1945年9月9日", "1945年10月1日"],
        correct: 0,
        explanation: "1945年8月15日，日本天皇宣布无条件投降。"
    }
];

// Role data
const roleData = {
    '地下党员': {
        story: "你是潜伏在敌占区的地下党员，表面上是普通商人，实际上却在为抗日前线传递重要情报。每一天都面临着暴露的危险，但你始终坚守信念，因为你知道，每一个情报都可能拯救无数同胞的生命。在关键时刻，你选择了战斗到底，用生命捍卫信仰。"
    },
    '抗日战士': {
        story: "你是前线作战部队的战士，经历过无数次战斗，见证了战友的牺牲。面对敌人的疯狂进攻，你从未退缩。在最后的抉择时刻，你毅然选择了战斗到底，因为你知道，身后是千千万万的同胞，是祖国的山河。"
    },
    '情报员': {
        story: "你是穿梭于敌人后方的情报员，每一次任务都是生死考验。你用智慧和勇气，将一个个重要情报送到抗日前线。在面临生死抉择时，你选择了战斗到底，因为你知道，情报的价值重于生命。"
    },
    '军医': {
        story: "你是战地医院的军医，每天都在与死神赛跑，救治受伤的战士。你见证了战争的残酷，也见证了人性的光辉。当敌人逼近医院时，你选择留下来保护伤员，用生命守护生命。"
    },
    '记者': {
        story: "你是战地记者，用笔和相机记录这段血与火的历史。你深入前线，用文字传递真相，用镜头记录历史。在最后的时刻，你选择继续报道，让世界看到中国人民的英勇抗争。"
    },
    '学生': {
        story: "你是爱国学生，虽然年轻，但心中燃烧着救国的火焰。你组织抗日宣传，参与地下工作，用实际行动证明青年的力量。面对敌人的威胁，你选择了战斗到底，用青春书写爱国篇章。"
    }
};

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeTypedText();
    initializeParticles();
    initializePhotoCarousel();
    initializeScrollAnimations();
    initializeQuiz();
    
    // Add smooth scrolling to navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
});

// Initialize typed text effect
function initializeTypedText() {
    const typed = new Typed('#typed-title', {
        strings: ['红色传承·青春使命', '铭记历史·担当使命', '传承精神·砥砺前行'],
        typeSpeed: 80,
        backSpeed: 50,
        backDelay: 2000,
        loop: true,
        showCursor: true,
        cursorChar: '|'
    });
}

// Initialize particle system
function initializeParticles() {
    const sketch = (p) => {
        let particles = [];
        
        p.setup = () => {
            const canvas = p.createCanvas(p.windowWidth, p.windowHeight);
            canvas.parent('particle-container');
            
            // Create particles
            for (let i = 0; i < 50; i++) {
                particles.push(new Particle(p));
            }
        };
        
        p.draw = () => {
            p.clear();
            
            // Update and display particles
            for (let particle of particles) {
                particle.update();
                particle.display();
            }
        };
        
        p.windowResized = () => {
            p.resizeCanvas(p.windowWidth, p.windowHeight);
        };
        
        class Particle {
            constructor(p) {
                this.p = p;
                this.x = p.random(p.width);
                this.y = p.random(p.height);
                this.vx = p.random(-0.5, 0.5);
                this.vy = p.random(-0.5, 0.5);
                this.size = p.random(2, 6);
                this.opacity = p.random(0.3, 0.8);
                this.color = p.random(['#FFD700', '#FF6B6B', '#4ECDC4']);
            }
            
            update() {
                this.x += this.vx;
                this.y += this.vy;
                
                // Wrap around edges
                if (this.x < 0) this.x = this.p.width;
                if (this.x > this.p.width) this.x = 0;
                if (this.y < 0) this.y = this.p.height;
                if (this.y > this.p.height) this.y = 0;
            }
            
            display() {
                this.p.fill(this.color + Math.floor(this.opacity * 255).toString(16));
                this.p.noStroke();
                this.p.ellipse(this.x, this.y, this.size);
            }
        }
    };
    
    new p5(sketch);
}

// Initialize photo carousel
function initializePhotoCarousel() {
    const splide = new Splide('#photo-carousel', {
        type: 'loop',
        autoplay: true,
        interval: 4000,
        pauseOnHover: true,
        arrows: true,
        pagination: true,
        gap: '2rem',
        breakpoints: {
            768: {
                gap: '1rem'
            }
        }
    });
    
    splide.mount();
}

// Initialize scroll animations
function initializeScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, observerOptions);
    
    // Observe all fade-in elements
    document.querySelectorAll('.fade-in').forEach(el => {
        observer.observe(el);
    });
}

// Initialize quiz
function initializeQuiz() {
    currentQuestionIndex = 0;
    quizScore = 0;
    selectedAnswers = new Array(quizData.length).fill(-1);
    displayQuestion();
}

// Display current question
function displayQuestion() {
    const question = quizData[currentQuestionIndex];
    const questionText = document.getElementById('question-text');
    const optionsContainer = document.getElementById('quiz-options');
    const currentQuestionSpan = document.getElementById('current-question');
    const totalQuestionsSpan = document.getElementById('total-questions');
    const prevBtn = document.getElementById('prev-btn');
    const nextBtn = document.getElementById('next-btn');
    
    questionText.textContent = question.question;
    currentQuestionSpan.textContent = currentQuestionIndex + 1;
    totalQuestionsSpan.textContent = quizData.length;
    
    // Clear options
    optionsContainer.innerHTML = '';
    
    // Create options
    question.options.forEach((option, index) => {
        const optionDiv = document.createElement('div');
        optionDiv.className = 'quiz-option';
        optionDiv.textContent = option;
        optionDiv.onclick = () => selectOption(index, optionDiv);
        
        // Highlight previously selected answer
        if (selectedAnswers[currentQuestionIndex] === index) {
            optionDiv.classList.add('selected');
        }
        
        optionsContainer.appendChild(optionDiv);
    });
    
    // Update button states
    prevBtn.disabled = currentQuestionIndex === 0;
    nextBtn.textContent = currentQuestionIndex === quizData.length - 1 ? '查看结果' : '下一题';
}

// Select quiz option
function selectOption(index, element) {
    // Remove previous selection
    document.querySelectorAll('.quiz-option').forEach(opt => {
        opt.classList.remove('selected', 'correct', 'incorrect');
    });
    
    // Mark selected option
    element.classList.add('selected');
    selectedAnswers[currentQuestionIndex] = index;
    
    // Show correct answer immediately
    const question = quizData[currentQuestionIndex];
    const options = document.querySelectorAll('.quiz-option');
    
    options[question.correct].classList.add('correct');
    if (index !== question.correct) {
        options[index].classList.add('incorrect');
    }
    
    // Add explanation
    setTimeout(() => {
        showExplanation(question.explanation);
    }, 500);
}

// Show explanation
function showExplanation(explanation) {
    // Remove existing explanation
    const existingExplanation = document.querySelector('.explanation');
    if (existingExplanation) {
        existingExplanation.remove();
    }
    
    const explanationDiv = document.createElement('div');
    explanationDiv.className = 'explanation mt-4 p-4 bg-blue-50 rounded-lg border-l-4 border-blue-400';
    explanationDiv.innerHTML = `<strong>解析：</strong>${explanation}`;
    
    document.getElementById('quiz-options').appendChild(explanationDiv);
}

// Next question
function nextQuestion() {
    if (currentQuestionIndex < quizData.length - 1) {
        currentQuestionIndex++;
        displayQuestion();
    } else {
        showQuizResult();
    }
}

// Previous question
function previousQuestion() {
    if (currentQuestionIndex > 0) {
        currentQuestionIndex--;
        displayQuestion();
    }
}

// Show quiz result
function showQuizResult() {
    // Calculate score
    quizScore = 0;
    selectedAnswers.forEach((answer, index) => {
        if (answer === quizData[index].correct) {
            quizScore++;
        }
    });
    
    const percentage = Math.round((quizScore / quizData.length) * 100);
    
    // Hide question container
    document.getElementById('quiz-question').style.display = 'none';
    document.querySelector('.flex.justify-between').style.display = 'none';
    
    // Show result
    const resultDiv = document.getElementById('quiz-result');
    const scoreSpan = document.getElementById('final-score');
    const messageP = document.getElementById('score-message');
    
    resultDiv.classList.remove('hidden');
    scoreSpan.textContent = `${quizScore}/${quizData.length} (${percentage}%)`;
    
    // Set message based on score
    let message = '';
    if (percentage >= 90) {
        message = '优秀！您对红色历史有很深的了解，是真正的红色传人！';
    } else if (percentage >= 70) {
        message = '良好！您对红色历史有较好的认识，继续加油！';
    } else if (percentage >= 60) {
        message = '及格！建议您多了解红色历史，传承革命精神。';
    } else {
        message = '需要加强学习。建议您深入了解抗日战争历史，增强爱国情怀。';
    }
    
    messageP.textContent = message;
}

// Restart quiz
function restartQuiz() {
    document.getElementById('quiz-result').classList.add('hidden');
    document.getElementById('quiz-question').style.display = 'block';
    document.querySelector('.flex.justify-between').style.display = 'flex';
    initializeQuiz();
}

// Role selection
function selectRole(element, roleName) {
    // Remove previous selection
    document.querySelectorAll('.role-card').forEach(card => {
        card.classList.remove('selected');
    });
    
    // Select current role
    element.classList.add('selected');
    
    // Show role description
    const descriptionDiv = document.getElementById('role-description');
    const storyP = document.getElementById('role-story');
    
    storyP.textContent = roleData[roleName].story;
    descriptionDiv.classList.remove('hidden');
    
    // Scroll to description
    descriptionDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

// Smooth scroll to section
function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        section.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }
}

// Mobile menu toggle
function toggleMobileMenu() {
    const menu = document.getElementById('mobile-menu');
    if (menu) {
        menu.classList.toggle('hidden');
    }
}

// Add scroll effect to navigation
window.addEventListener('scroll', () => {
    const nav = document.querySelector('nav');
    if (window.scrollY > 100) {
        nav.classList.add('shadow-lg');
    } else {
        nav.classList.remove('shadow-lg');
    }
});

// Add loading animation
window.addEventListener('load', () => {
    document.body.classList.add('loaded');
    
    // Animate hero elements
    anime({
        targets: '.hero-title',
        opacity: [0, 1],
        translateY: [50, 0],
        duration: 1000,
        easing: 'easeOutQuart',
        delay: 500
    });
    
    anime({
        targets: '.hero-bg p',
        opacity: [0, 1],
        translateY: [30, 0],
        duration: 800,
        easing: 'easeOutQuart',
        delay: 1000
    });
    
    anime({
        targets: '.hero-bg .flex',
        opacity: [0, 1],
        translateY: [20, 0],
        duration: 600,
        easing: 'easeOutQuart',
        delay: 1500
    });
});

// Add parallax effect to hero section
window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const hero = document.querySelector('.hero-bg');
    if (hero) {
        hero.style.transform = `translateY(${scrolled * 0.5}px)`;
    }
});

// Add hover effects to cards
document.addEventListener('DOMContentLoaded', function() {
    const cards = document.querySelectorAll('.card-hover');
    
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            anime({
                targets: this,
                scale: 1.02,
                duration: 300,
                easing: 'easeOutQuart'
            });
        });
        
        card.addEventListener('mouseleave', function() {
            anime({
                targets: this,
                scale: 1,
                duration: 300,
                easing: 'easeOutQuart'
            });
        });
    });
});

// Add click ripple effect
function addRippleEffect(element) {
    const ripple = document.createElement('span');
    const rect = element.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = event.clientX - rect.left - size / 2;
    const y = event.clientY - rect.top - size / 2;
    
    ripple.style.cssText = `
        position: absolute;
        width: ${size}px;
        height: ${size}px;
        left: ${x}px;
        top: ${y}px;
        background: rgba(255, 255, 255, 0.3);
        border-radius: 50%;
        transform: scale(0);
        animation: ripple 0.6s linear;
        pointer-events: none;
    `;
    
    element.style.position = 'relative';
    element.style.overflow = 'hidden';
    element.appendChild(ripple);
    
    setTimeout(() => {
        ripple.remove();
    }, 600);
}

// Add ripple animation CSS
const style = document.createElement('style');
style.textContent = `
    @keyframes ripple {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Add ripple effect to buttons
document.addEventListener('click', function(e) {
    if (e.target.matches('button, .role-card, .quiz-option')) {
        addRippleEffect(e.target);
    }
});

// Add keyboard navigation for quiz
document.addEventListener('keydown', function(e) {
    if (document.getElementById('quiz-container').contains(e.target)) {
        if (e.key === 'ArrowLeft') {
            previousQuestion();
        } else if (e.key === 'ArrowRight') {
            nextQuestion();
        } else if (e.key >= '1' && e.key <= '4') {
            const optionIndex = parseInt(e.key) - 1;
            const options = document.querySelectorAll('.quiz-option');
            if (options[optionIndex]) {
                selectOption(optionIndex, options[optionIndex]);
            }
        }
    }
});

// Add social sharing functionality
function shareToWeChat() {
    // Simulate WeChat sharing
    alert('分享功能需要在微信环境中使用');
}

function generateShareImage() {
    // Generate a shareable image with the activity info
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = 800;
    canvas.height = 600;
    
    // Set background
    ctx.fillStyle = '#C41E3A';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Add text
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 48px serif';
    ctx.textAlign = 'center';
    ctx.fillText('红色传承·青春使命', canvas.width / 2, 100);
    
    ctx.font = '24px sans-serif';
    ctx.fillText('武汉大学物理学院团日活动', canvas.width / 2, 150);
    ctx.fillText('2024年10月24日', canvas.width / 2, 200);
    
    // Add decorative elements
    ctx.fillStyle = '#FFD700';
    ctx.font = '36px serif';
    ctx.fillText('★ ★ ★', canvas.width / 2, 300);
    
    // Convert to image and download
    const link = document.createElement('a');
    link.download = '团日活动分享图.png';
    link.href = canvas.toDataURL();
    link.click();
}

// Export functions for global access
window.scrollToSection = scrollToSection;
window.selectRole = selectRole;
window.selectOption = selectOption;
window.nextQuestion = nextQuestion;
window.previousQuestion = previousQuestion;
window.restartQuiz = restartQuiz;
window.toggleMobileMenu = toggleMobileMenu;
window.shareToWeChat = shareToWeChat;
window.generateShareImage = generateShareImage;